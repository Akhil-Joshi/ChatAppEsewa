import nltk
nltk.download('vader_lexicon')